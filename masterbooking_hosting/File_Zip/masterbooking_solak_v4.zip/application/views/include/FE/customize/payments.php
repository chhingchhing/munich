<div class="col-sm-12 form-booking" id="payments">
	<h2>Payments</h2>
	<hr>
	<?php echo anchor("site/customizes/personal-info","Add your member(s)", array('role' => 'button', 'class' => 'btn btn-success btn-sm')); ?>
	<?php echo anchor("site/customizes/personal-info","Pay Later", array('role' => 'button', 'class' => 'btn btn-warning btn-sm')); ?>
	<button type="submit" class="btn btn-primary btn-sm" name="btnTripInfo"> Finish </button>
<p></p>
</div>
	   <!-- end div home -->