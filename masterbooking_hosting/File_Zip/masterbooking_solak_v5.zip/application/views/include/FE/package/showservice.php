<div class="row clearfix wrap_customize">
<div class="col-sm-12 titleBooking">
	<h1>Booking Tours</h1>
	<h2>Add Extra Services</h2>
</div>
<div class="col-sm-12">
<div class="col-sm-10">
		<div class="mainmadia" style="background-color:#f0f9f0;">
		<?php 
			echo form_open("site/packages/showservice", 'class="frmService"');
			if(isset($packageExtraservice)){
				if($packageExtraservice->num_rows() > 0){
					foreach($packageExtraservice->result() as $service){
		?>
				<div class="media col-lg-12">
				  <div class="col-lg-2 pk_img">
				  	<?php 
					    $imgname = $service->pho_source;
					    echo img(array('src'=>'user_uploads/thumbnail/original/'.$imgname ,'alt'=>'Extra service','class'=>'img-responsive img-thumbnail')); 
					?>
				  </div>
				  <div class="media-body">
				  	<?php 
				  		$checked = false;
				  	    if($this->session->userdata('extraservice')){
				  	    	$epselected = $this->session->userdata('extraservice');
				  	    	if(isset($epselected[$service->ep_id]) && $epselected[$service->ep_id] == $service->ep_id) $checked = true;
				  		}
				  	?>
				    <h4 class="media-heading"><?php echo form_checkbox(array('name' => 'epchecked['.$service->ep_id.']','value'=>set_value('epchecked',$service->ep_id), 'class'=>'checkIt', 'checked' => $checked)).nbs(3); echo $service->ep_name.nbs(3);  echo '$'.$service->ep_saleprice;?></h4>
				    <p><?php echo $service->ep_bookingtext; ?></p>
				  </div>
				</div>
		<?php
					}

				}else{
					echo "No Extra Services available...";
				}
			}else{
				echo "No Extra Services available...";
			}
		?>
		
		</div>
		<br />
		<?php 
			$key = "90408752631";
            $pk_id = base64url_encode($key.$this->session->userdata('pkID'));
			echo form_submit(array('name'=>'submitService','value'=>'Continue','class'=>"btn btn-primary")).nbs(5);
			echo anchor('site/packages/details/'.$pk_id,'Back', 'class="btn btn-default"');
		echo form_close();
		?>
	</div>
	<div class="col-sm-2 form-order">
		<h4 class="infoheader" style="padding:5px;border-bottom: 1px dotted #cccccc;">Price</h4>
		<p style="padding:5px;">Special Price only $<?php echo $this->session->userdata('pkprice'); ?> per person! You will get best experience with our services.</p>
	</div>
</div>
</div>