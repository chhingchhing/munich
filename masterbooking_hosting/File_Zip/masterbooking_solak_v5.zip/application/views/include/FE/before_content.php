<div class="container">
	<div class="row header_tem">
		<div class="col-md-6 languages_icon">
        	<a href="#"><img src="<?php echo base_url();?>/assets/img/FE/english.png" class="img-responsive" alt="Responsive image"/></a>
            <a href="#"><img src="<?php echo base_url();?>/assets/img/FE/french.png" class="img-responsive" alt="Responsive image"/></a>
            <a href="#"><img src="<?php echo base_url();?>/assets/img/FE/germany.png" class="img-responsive" alt="Responsive image"/></a>
            <a href="#"><img src="<?php echo base_url();?>/assets/img/FE/nererland.png" class="img-responsive" alt="Responsive image"/></a>
        </div>
	   	<div class="col-md-6 logo">
        	<a href="#"><img src="<?php echo base_url();?>/assets/img/FE/logo_ct.png" class="img-responsive" alt="Responsive image"/></a>
        </div>
	</div>
	
	<?php $this->load->view(INCLUDE_FE.'menu');?>
	<?php $this->load->view(INCLUDE_FE.'slideshow');?>
	<div class="div-before-content">&nbsp;</div>

