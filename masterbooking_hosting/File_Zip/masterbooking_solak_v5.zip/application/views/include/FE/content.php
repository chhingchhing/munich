<div class="row">
  <div class="col-lg-4">
    <h1 class="h1_sm">Titel1</h1>
      <p>
      CodeIgniter lets you set as many validation rules as you need for a given field, 
      cascading them in order, and it even lets you prep and pre-process the field data at the same time. 
      To set validation rules you will use the set_rules() function: <a href="#" class="readmore" >read more</a>
      </p>
  </div>
  <div class="col-lg-4">
    <h1 class="h1_sm">Titel2</h1>
      <p>
      CodeIgniter lets you set as many validation rules as you need for a given field, 
      cascading them in order, and it even lets you prep and pre-process the field data at the same time. 
      To set validation rules you will use the set_rules() function: <a href="#" class="readmore" >read more</a>                  
    </p>
  </div>
  <div class="col-lg-4">
    <h1 class="h1_sm">Titel3</h1>
      <p>
      CodeIgniter lets you set as many validation rules as you need for a given field, 
      cascading them in order, and it even lets you prep and pre-process the field data at the same time. 
      To set validation rules you will use the set_rules() function: <a href="#" class="readmore" >read more</a>
      </p>
  </div>         
</div>  