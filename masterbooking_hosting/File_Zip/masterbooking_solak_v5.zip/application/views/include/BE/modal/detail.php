<div class="modal fade" id="activitiesViewModal" tabindex="-1" role="dialog" aria-labelledby="activitesModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="activitesModalLabel">Detail</h4>
      </div>
      <div class="modal-body modal-activities-body">
        &nbsp;
      </div>
      <div class="modal-footer modal-activities-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>