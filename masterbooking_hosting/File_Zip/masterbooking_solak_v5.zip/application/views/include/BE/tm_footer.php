<div style="clear:both;">&nbsp;</div>
<div class="row clearfix footer">
	<center><p>Copy@right By: <a href="#">Codingate Team</a></p></center>
</div>
