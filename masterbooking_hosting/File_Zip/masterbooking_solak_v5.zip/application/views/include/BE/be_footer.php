	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/External/jquery-1.11.0.min.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/External/bootstrap.min.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/External/tinymce/tinymce.min.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/BE/scripts.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/BE/manage.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/BE/bebooking.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/BE/transportation.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/BE/accommodation.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/BE/package.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/BE/customize.js"></script>
	    <script type="text/javascript" src="<?php echo base_url(); ?>assets/datepicker/js/jquery.js"></script>
            <script type="text/javascript" src="<?php echo base_url(); ?>assets/datepicker/js/bootstrap-datepicker.js"></script>
            <script type="text/javascript" src="<?php echo base_url(); ?>assets/datepicker/js/bootstrap-timepicker.js"></script>
            <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/BE/jquery.ddslick.min.js"></script>  
    </body>
</html>