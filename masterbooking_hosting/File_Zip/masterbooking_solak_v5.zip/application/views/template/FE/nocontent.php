<?php $this->load->view(INCLUDE_FE.'before_content'); ?>   
<div class="row clearfix">
	Sorry this page is not available.
</div>
<?php $this->load->view(INCLUDE_FE.'after_content'); ?>
