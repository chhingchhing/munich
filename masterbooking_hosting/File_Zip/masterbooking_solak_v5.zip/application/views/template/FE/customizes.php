<?php //$this->load->view(INCLUDE_FE.'before_content'); ?>   
<?php $this->load->view(INCLUDE_FE.'customize'); ?>
<?php //$this->load->view(INCLUDE_FE.'after_content'); ?>
