<div class="col-sm-12 form-booking" id="payments">
	   		<h2>Payments</h2>
	   		<hr>
			<button type="submit" class="btn btn-primary btn-sm" name="btnTripInfo"> Finish </button>
<p></p>
</div>
	   <!-- end div home -->