<div class="row clearfix">
	<div class="col-lg-12 txtTitleChoose">
		<h2>Booking Tours</h2>
		<h3>Choose Type of Booking</h3>
	</div>
	<div class="clearfix">&nbsp;</div>
	<div class="col-lg-3 col-xs-6 col-sm-offset-3">
		<?php echo anchor('site/packages', img(array('src'=>'assets/img/FE/package.jpg','alt'=>'packages','class'=>'img-responsive img-thumbnail'))); ?> 
        <h4>Wanna us to organize the trip?</h4>
		<p class="clearfix"></p>
	</div>
	<div class="col-lg-3 col-xs-6">
		<?php echo anchor('site/customizes', img(array('src'=>'assets/img/FE/customize.jpg','alt'=>'customizes','class'=>'img-responsive img-thumbnail'))); ?> 
        <h4>Wanna us to organize the trip?</h4>
		<p class="clearfix"></p>
	</div>
</div>