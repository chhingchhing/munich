 
<?php
echo include_js(array( 
	'assets/js/External/jquery-1.10.2.min.js',
        //for date and time
	'assets/js/FE/date-time.js', 	
	// end js for date and time
        'assets/js/External/bootstrap.js',
        'assets/js/External/bootstrap.min.js',
        'assets/js/External/bootstrap-carousel.js',
        'assets/js/External/html5shiv.js',
	//for slideshow,
	'assets/js/External/jquery.slides.min.js',
	'assets/js/FE/slideshowfe.js',
	'assets/js/FE/script_fe.js',
	//end slideshow
        // add date picker
	'assets/js/FE/bootstrap-datepicker.js',
	'assets/js/FE/bootstrap-timepicker.js',
	// end date picker
    ));
?>
