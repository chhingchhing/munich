<div class="modal fade" id="accommodationViewModal" tabindex="-1" role="dialog" aria-labelledby="accommodationModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="accommodationModalLabel">Detail</h4>
      </div>
      <div class="modal-body modal-accommodation-body">
        &nbsp;
      </div>
      <div class="modal-footer modal-accommodation-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>