<!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="utf-8">
            <title>Munich Administrator</title>
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <meta name="description" content="">
            <meta name="author" content="">
            <?php
                echo link_tag("assets/css/External/bootstrap.min.css");
                // echo link_tag("assets/css/External/bootstrap-responsive.min.css");
                echo link_tag("assets/css/External/icons.css");
                echo link_tag("assets/css/BE/style.css");
                echo link_tag("assets/datepicker/css/jquery-ui.css");
                echo link_tag("assets/datepicker/css/bootstrap-timepicker.css");
                echo link_tag("assets/datepicker/css/datepicker.css");
            ?>
        <link rel="shortcut icon" href="<?php echo base_url(); ?>/assets/img/BE/codingate.ico">
    </head>

<body class="body">
