 <h4>Edit Package</h4>
                    <form class="form-horizontal" role="form">
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Package Name :</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Start date :</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">End date :</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Description:</label>
                            <div class="col-sm-4">
                                <textarea class="form-control" rows="3"></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Original Price :</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control">
                            </div>
                            <label class="col-sm-2 control-label">Original Stock :</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Actual Price :</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control">
                            </div>
                            <label class="col-sm-2 control-label">Actual Stock :</label>
                            <div class="col-sm-2">
                                <input type="text" class="form-control">
                            </div>
                        </div>
                      <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                          <button type="submit" class="btn btn-primary">Update</button>
                          <button type="submit" class="btn btn-primary">Cancel</button>
                        </div>
                      </div>
                    </form>
            </div>       
