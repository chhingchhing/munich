<?php $this->load->view(INCLUDE_FE.'before_content'); ?>   
<div class="row clearfix">
    <?php $this->load->view(INCLUDE_FE.'profile'); ?>
</div>
<?php $this->load->view(INCLUDE_FE.'after_content'); ?>
