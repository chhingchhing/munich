<div class="modal fade" id="transportationViewModal" tabindex="-1" role="dialog" aria-labelledby="transportationModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="transportationModalLabel">Detail</h4>
      </div>
      <div class="modal-body modal-transportation-body">
        &nbsp;
      </div>
      <div class="modal-footer modal-transportation-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>